package it.example.hotelautomation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelautomationApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelautomationApplication.class, args);
	}

}
