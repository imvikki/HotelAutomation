package it.example.hotelautomation.interfaces.exception;

public class HotelAutomationException extends RuntimeException {

    public HotelAutomationException(String message) {
        super(message);
    }

}
