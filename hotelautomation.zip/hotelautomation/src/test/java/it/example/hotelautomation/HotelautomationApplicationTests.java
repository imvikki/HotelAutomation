package it.example.hotelautomation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelautomationApplicationTests {

	@Test
	void contextLoads() {
	}

}
